
import {
  User, UserRole, Timeslot, Meeting, Location, Announcement,
  TimeslotDuration, Coordinates, MeetingStatus
} from '../types';
import { INITIAL_USERS, INITIAL_LOCATIONS, POINT_VALUES, TIMBERCREEK_CHURCH_COORDS } from '../constants';
import { v4 as uuidv4 } from 'uuid';
import { differenceInMinutes, addMinutes, endOfWeek, addDays, isSameDay, format } from 'date-fns';
import startOfWeek from 'date-fns/startOfWeek';
import parseISO from 'date-fns/parseISO';
import { getDistance } from 'geolib';

const LOCAL_STORAGE_KEY_USERS = 'timbercreek_users_v5';
const LOCAL_STORAGE_KEY_TIMESLOTS = 'timbercreek_timeslots_v5';
const LOCAL_STORAGE_KEY_MEETINGS = 'timbercreek_meetings_v5';
const LOCAL_STORAGE_KEY_ANNOUNCEMENTS = 'timbercreek_announcements_v5';
const LOCAL_STORAGE_KEY_LOCATIONS = 'timbercreek_locations_v32'; // Bumped to v32

const SIMULATED_LATENCY = 300; 

function simulateDelay(): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, SIMULATED_LATENCY));
}

function loadFromLocalStorage<T>(key: string, initialData: T[]): T[] {
  try {
    const data = localStorage.getItem(key);
    if (data) {
      return JSON.parse(data, (k, v) => {
        if (typeof v === 'string' && k.toLowerCase().includes('time') && !isNaN(new Date(v).getTime())) {
          return new Date(v);
        }
        return v;
      });
    }
  } catch (error) {
    console.error(`Failed to load data from localStorage for key "${key}":`, error);
  }
  return initialData;
}

function saveToLocalStorage<T>(key: string, data: T[]): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (error) {
    console.error(`Failed to save data to localStorage for key "${key}":`, error);
  }
}

let _users: User[] = loadFromLocalStorage(LOCAL_STORAGE_KEY_USERS, INITIAL_USERS);
let _timeslots: Timeslot[] = loadFromLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, []);
let _meetings: Meeting[] = loadFromLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, []);
let _announcements: Announcement[] = loadFromLocalStorage(LOCAL_STORAGE_KEY_ANNOUNCEMENTS, []);

// Load locations, but FORCE UPDATE known locations to fix map pin issues
let _loadedLocations: Location[] = loadFromLocalStorage(LOCAL_STORAGE_KEY_LOCATIONS, INITIAL_LOCATIONS);
let _locations: Location[] = _loadedLocations.map(loc => {
  // Check if this location corresponds to one of our hardcoded initials
  const initialMatch = INITIAL_LOCATIONS.find(init => init.id === loc.id);
  if (initialMatch) {
    // Force update coordinates to match constants.ts
    return {
      ...loc,
      latitude: initialMatch.latitude,
      longitude: initialMatch.longitude,
      address: initialMatch.address, // Ensure address matches too
      isStatic: true, // Re-affirm static status
      approxDriveMinutes: initialMatch.approxDriveMinutes
    };
  }
  return loc;
});

// If new locations were added to constants that aren't in storage, add them
INITIAL_LOCATIONS.forEach(init => {
  if (!_locations.find(l => l.id === init.id)) {
    _locations.push(init);
  }
});

// Save the patched locations back to storage immediately
saveToLocalStorage(LOCAL_STORAGE_KEY_LOCATIONS, _locations);


// Sanity check: If local storage locations are empty (edge case), restore initial
if (_locations.length === 0) {
    _locations = [...INITIAL_LOCATIONS];
}

if (_timeslots.length === 0 && _meetings.length === 0) {
  const hostUser = _users.find(u => u.role === UserRole.MEMBER); 
  const attendeeUser = _users.find(u => u.role === UserRole.MEMBER && u.id !== hostUser?.id); 
  const location = _locations[0];

  if (hostUser && attendeeUser && location) {
    const now = new Date();
    const nextMonday = addDays(startOfWeek(now, { weekStartsOn: 1 }), 0); 
    const nextMonday10AM = new Date(nextMonday.setHours(10, 0, 0, 0));
    const nextWednesday3PM = new Date(addDays(nextMonday, 2).setHours(15, 0, 0, 0));

    const unbookedSlot: Timeslot = {
      id: uuidv4(),
      hostUserId: hostUser.id,
      startTime: nextMonday10AM,
      durationMinutes: TimeslotDuration.SIXTY_MINUTES,
      locationId: location.id,
      isBooked: false,
      repeatWeekly: false,
    };
    _timeslots.push(unbookedSlot);

    const bookedSlotStartTime = nextWednesday3PM;
    const bookedSlot: Timeslot = {
      id: uuidv4(),
      hostUserId: hostUser.id,
      startTime: bookedSlotStartTime,
      durationMinutes: TimeslotDuration.SIXTY_MINUTES,
      locationId: location.id,
      isBooked: true,
      bookedByUserId: attendeeUser.id,
      repeatWeekly: false,
    };
    _timeslots.push(bookedSlot);

    const meeting: Meeting = {
      id: uuidv4(),
      hostUserId: hostUser.id,
      attendeeUserId: attendeeUser.id,
      timeslotId: bookedSlot.id,
      locationId: bookedSlot.locationId,
      startTime: bookedSlot.startTime,
      durationMinutes: bookedSlot.durationMinutes,
      status: MeetingStatus.CONFIRMED,
    };
    _meetings.push(meeting);

    saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
    saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
  }
}

export const apiService = {
  async getUsers(): Promise<User[]> { await simulateDelay(); return [..._users]; },
  async getUser(id: string): Promise<User | undefined> { await simulateDelay(); return _users.find(u => u.id === id); },
  async createUser(user: Omit<User, 'id' | 'points'>): Promise<User> {
    await simulateDelay();
    const newUser: User = { ...user, id: uuidv4(), points: 0 };
    _users.push(newUser);
    saveToLocalStorage(LOCAL_STORAGE_KEY_USERS, _users);
    return newUser;
  },
  async updateUser(user: User): Promise<User> {
    await simulateDelay();
    const index = _users.findIndex(u => u.id === user.id);
    if (index !== -1) {
      _users[index] = user;
      saveToLocalStorage(LOCAL_STORAGE_KEY_USERS, _users);
      return user;
    }
    throw new Error('User not found');
  },
  async deleteUser(id: string): Promise<void> {
    await simulateDelay();
    _users = _users.filter(u => u.id !== id);
    saveToLocalStorage(LOCAL_STORAGE_KEY_USERS, _users);
  },
  async updatePoints(userId: string, points: number): Promise<User | undefined> {
    await simulateDelay();
    const user = _users.find(u => u.id === userId);
    if (user) {
      user.points += points;
      saveToLocalStorage(LOCAL_STORAGE_KEY_USERS, _users);
      return user;
    }
    return undefined;
  },
  async getTimeslots(): Promise<Timeslot[]> { await simulateDelay(); return [..._timeslots]; },
  async createTimeslot(timeslot: Omit<Timeslot, 'id' | 'isBooked'>, userId: string): Promise<Timeslot> {
    await simulateDelay();
    const newTimeslot: Timeslot = { ...timeslot, id: uuidv4(), isBooked: false };
    _timeslots.push(newTimeslot);
    saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
    await apiService.updatePoints(userId, POINT_VALUES.POST_TIMESLOT);
    return newTimeslot;
  },
  async updateTimeslot(timeslot: Timeslot): Promise<Timeslot> {
    await simulateDelay();
    const index = _timeslots.findIndex(t => t.id === timeslot.id);
    if (index !== -1) {
      _timeslots[index] = timeslot;
      saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
      return timeslot;
    }
    throw new Error('Timeslot not found');
  },
  async deleteTimeslot(id: string): Promise<void> {
    await simulateDelay();
    _timeslots = _timeslots.filter(t => t.id !== id);
    saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
  },
  async getMeetings(): Promise<Meeting[]> { await simulateDelay(); return [..._meetings]; },
  async createMeeting(meeting: Omit<Meeting, 'id'>, hostId: string, attendeeId: string): Promise<Meeting> {
    await simulateDelay();
    const newMeeting: Meeting = { ...meeting, id: uuidv4() };
    _meetings.push(newMeeting);
    saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
    await apiService.updatePoints(hostId, POINT_VALUES.ACCEPT_MEETING);
    await apiService.updatePoints(attendeeId, POINT_VALUES.ACCEPT_MEETING);
    return newMeeting;
  },
  async updateMeeting(meeting: Meeting): Promise<Meeting> {
    await simulateDelay();
    const index = _meetings.findIndex(m => m.id === meeting.id);
    if (index !== -1) {
      _meetings[index] = meeting;
      saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
      return meeting;
    }
    throw new Error('Meeting not found');
  },
  async cancelMeeting(meetingId: string, cancellingUserId: string): Promise<Meeting> {
    await simulateDelay();
    const meeting = _meetings.find(m => m.id === meetingId);
    if (!meeting) throw new Error('Meeting not found');
    if (meeting.status === MeetingStatus.CANCELLED) throw new Error('Meeting already cancelled');
    meeting.status = MeetingStatus.CANCELLED;
    saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
    const timeslot = _timeslots.find(t => t.id === meeting.timeslotId);
    if (timeslot) {
      timeslot.isBooked = false;
      timeslot.bookedByUserId = undefined;
      saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
    }
    return meeting;
  },
  async completeMeeting(meetingId: string): Promise<Meeting> {
    await simulateDelay();
    const meeting = _meetings.find(m => m.id === meetingId);
    if (!meeting) throw new Error('Meeting not found');
    if (meeting.status !== MeetingStatus.CONFIRMED) throw new Error('Meeting is not confirmed');
    meeting.status = MeetingStatus.COMPLETED;
    saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
    await apiService.updatePoints(meeting.hostUserId, POINT_VALUES.COMPLETE_MEETING);
    await apiService.updatePoints(meeting.attendeeUserId, POINT_VALUES.COMPLETE_MEETING);
    return meeting;
  },
  async getLocations(): Promise<Location[]> {
    await simulateDelay();
    // Return the managed location list, sorted by name, NEW COPY
    return [..._locations].sort((a, b) => a.name.localeCompare(b.name));
  },
  async addLocation(location: Omit<Location, 'id' | 'isApproved'>, submittedByUserId?: string): Promise<Location> {
    await simulateDelay();
    // For new user-submitted locations, we default isStatic to false so geocoding can possibly be used if coords are weak
    const newLocation: Location = { 
        ...location, 
        id: uuidv4(), 
        isApproved: false, 
        submittedByUserId, 
        isStatic: false 
    };
    _locations.push(newLocation);
    saveToLocalStorage(LOCAL_STORAGE_KEY_LOCATIONS, _locations);
    if (submittedByUserId) await apiService.updatePoints(submittedByUserId, POINT_VALUES.SUBMIT_LOCATION);
    return newLocation;
  },
  async approveLocation(locationId: string, adminUserId: string): Promise<Location> {
    await simulateDelay();
    const location = _locations.find(l => l.id === locationId);
    if (!location) throw new Error('Location not found');
    location.isApproved = true;
    saveToLocalStorage(LOCAL_STORAGE_KEY_LOCATIONS, _locations);
    if (location.submittedByUserId) await apiService.updatePoints(location.submittedByUserId, POINT_VALUES.APPROVE_LOCATION);
    return location;
  },
  async deleteLocation(id: string): Promise<void> {
    await simulateDelay();
    _locations = _locations.filter(l => l.id !== id);
    _timeslots = _timeslots.filter(t => t.locationId !== id);
    _meetings = _meetings.filter(m => m.locationId !== id);
    saveToLocalStorage(LOCAL_STORAGE_KEY_LOCATIONS, _locations);
    saveToLocalStorage(LOCAL_STORAGE_KEY_TIMESLOTS, _timeslots);
    saveToLocalStorage(LOCAL_STORAGE_KEY_MEETINGS, _meetings);
  },
  async getAnnouncements(): Promise<Announcement[]> { await simulateDelay(); return [..._announcements].sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime()); },
  async createAnnouncement(announcement: Omit<Announcement, 'id'>): Promise<Announcement> {
    await simulateDelay();
    const newAnnouncement: Announcement = { ...announcement, id: uuidv4(), timestamp: new Date() };
    _announcements.push(newAnnouncement);
    saveToLocalStorage(LOCAL_STORAGE_KEY_ANNOUNCEMENTS, _announcements);
    return newAnnouncement;
  },
  async deleteAnnouncement(id: string): Promise<void> {
    await simulateDelay();
    _announcements = _announcements.filter(a => a.id !== id);
    saveToLocalStorage(LOCAL_STORAGE_KEY_ANNOUNCEMENTS, _announcements);
  },
  generateICSFile(meeting: Meeting, location: Location, host: User, attendee: User): string {
    const start = format(meeting.startTime, 'yyyyMMdd\'T\'HHmmss');
    const end = format(addMinutes(meeting.startTime, meeting.durationMinutes), 'yyyyMMdd\'T\'HHmmss');
    const googleMapsLink = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(location.address)}`;
    return `BEGIN:VCALENDAR
VERSION:2.0
PRODID:-//Timbercreek Men's Connect//NONSGML v1.0//EN
BEGIN:VEVENT
UID:${meeting.id}
DTSTAMP:${format(new Date(), 'yyyyMMdd\'T\'HHmmss\'Z\'')}
DTSTART:${start}
DTEND:${end}
SUMMARY:Coffee Connect with ${attendee.name}
DESCRIPTION:Location: ${location.name}, ${location.address}\\nView on Google Maps: ${googleMapsLink}
LOCATION:${location.name}, ${location.address}
END:VEVENT
END:VCALENDAR`;
  },
  async sendSMSNotification(toPhoneNumber: string, message: string): Promise<boolean> {
    await simulateDelay();
    console.log(`--- SIMULATED SMS SENT TO ${toPhoneNumber}: ${message} ---`);
    return true;
  },
  async getCurrentLocation(): Promise<Coordinates> {
    await simulateDelay();
    return { latitude: TIMBERCREEK_CHURCH_COORDS.latitude, longitude: TIMBERCREEK_CHURCH_COORDS.longitude };
  }
};
